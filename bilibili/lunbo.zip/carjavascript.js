//取出所有导航点
var nav = document.getElementsByClassName("nav")[0].children;
//取出所有轮播内容  大盒子
var content = document.getElementsByClassName("content")[0].children[1];
//上一个
var up = document.getElementsByClassName("up")[0];
//下一个
var next = document.getElementsByClassName("next")[0];
//计数器
var add = 0;
//步数  每次执行计数器图片偏移量px
var seat = 15;
//设置轮播大盒子初始位置
content.style.marginLeft= "0px";
//判断状态  节流
var fk = true;
//给所有导航点加鼠标事件
for(var i = 0; i < nav.length; i++){
    //设置索引值
    nav[i].setAttribute("index",i);
    //导航焦点点击事件
    nav[i].onclick = function(){
        //设置节流
        //点击触发 进入函数体 将fk改为false 锁住 暴力点击无效
        if(fk){
            fk = false;
        index = Number( this.getAttribute("index"));
        //排他 添加吃豆人
        add = index;
        for(var j = 0; j < nav.length; j++){
            nav[j].style = '';
        }
        //目标位置
        var end = -440*index;
        //初始位置
        var seat = 15;
        var st = parseInt(content.style.marginLeft);
        //如果初始位置大于目标位置 既需要向左平移 
        //如果初始位置小于目标位置 既需要向右平移
        //只需要改变步数的正负值就可以改变 向右向左平移
        seat =  st > end ? seat:-seat;
        //开启计数器
        var time = setInterval(function(){
            //初始位置
            var st = parseInt(content.style.marginLeft);
            //每次执行计数器 偏移数
                content.style.marginLeft = st -seat + "px";
                //将偏移后的位置重新赋值给初始位置
                st = parseInt(content.style.marginLeft);
                //步数为正 则向左平移 
                if(seat > 0){
                    //偏移到目标位置之后 可能会偏移过量
                    if (st < end){
                        //打开函数节流
                        fk = true;
                        //停止偏移
                        clearInterval(time);
                        //将位置矫正
                        content.style.marginLeft = index*-440+"px";
                    }
                }
                //步数为负 则向右平移 
                else{
                    if (st > end){
                        fk = true;
                        clearInterval(time);
                        content.style.marginLeft = index*-440+"px";
                    }
                }
        },10)
        this.style = "background: url('img/icon.png')no-repeat -855px -726px;"
        }
    }
}
//下一个
next.onclick = function(){
    //函数节流
    if (fk){
        fk = false;
        //每次点击计数器加1
        add++;
        //因为有5张图 所以当计数到5之后 将计数器重置 
        if(add >= 5){
            add = 0;
                var time = setInterval(function(){
                    var st = parseInt(content.style.marginLeft);
                    //由最后一张调到第一张需要向左偏移 所以为加
                    content.style.marginLeft = st+seat +"px";
                    st = parseInt(content.style.marginLeft);
                    //偏移多少由 图片宽度乘以 点击次数 既到达目标位置
                    if(st > -440*add ){
                        fk = true;
                        clearInterval(time);
                        content.style.marginLeft = -440*add +"px";
                    }
                },1);
        }
        //正常情况 计点击次数0~4次时
        else{
            var time = setInterval(function(){
                var st = parseInt(content.style.marginLeft);
                   //由初始调到目标需要向左偏移 所以为减
                content.style.marginLeft = st-seat +"px";
                st = parseInt(content.style.marginLeft);
                if(st < -440*add ){
                    fk = true;
                    clearInterval(time);
                    content.style.marginLeft = -440*add +"px";
                }
            },10);
        } 
        for(var j = 0; j < nav.length; j++){
            nav[j].style = "";
        }
        nav[add].style = style = "background: url('img/icon.png')no-repeat -855px -726px;"
    }
}
up.onclick = function(){
    if (fk){
        fk = false;
        add--;
        if(add == -1){
            add = 4;
            var time = setInterval(function(){
                var st = parseInt(content.style.marginLeft);
                content.style.marginLeft = st - seat +"px";
                st = parseInt(content.style.marginLeft);
                if(st < -440 * add){
                    fk = true;
                    clearInterval(time);
                    content.style.marginLeft = -440*add + "px";
                } 
            },10);
        }
    else{
        var time = setInterval(function(){
            var st = parseInt( content.style.marginLeft);
            content.style.marginLeft = st + seat +"px";
            st = parseInt(content.style.marginLeft);
            if(st > -440*add){
                clearInterval(time);
                fk = true;
                content.style.marginLeft = -440*add + "px";
            }
        },10);
    }
    for(var j = 0; j < nav.length; j++){
        nav[j].style = "";
    }
    nav[add].style = style = "background: url('img/icon.png')no-repeat -855px -726px;"
    }
}